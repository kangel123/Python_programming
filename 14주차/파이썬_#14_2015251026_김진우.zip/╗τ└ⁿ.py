english_dic = dict()
english_dic['one']='하나'
english_dic['two']='둘'
english_dic['three']='셋'
word = input("영단어를 입력하시오. : ")
print(english_dic[word])

korean_dic = {"하나":"one", "둘":"two", "셋": "three"}
word = input("단어를 입력하시오. : ")
print(korean_dic[word])
